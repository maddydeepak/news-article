import React from "react";
import MainContainer from "./MainContainer";

const Body = () => {
  return (
    <div className="bg-gray-700 ">
      <MainContainer />
    </div>
  );
};

export default Body;
