import logo from "./logo.svg";
import "./App.css";
import Body from "./components/Body";

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <Body />
      </header>
    </div>
  );
}

export default App;
